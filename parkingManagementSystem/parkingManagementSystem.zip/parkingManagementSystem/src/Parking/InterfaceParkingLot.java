package Parking;

public interface InterfaceParkingLot {
    //method for calculating payment
    void calculatePayment();
}
